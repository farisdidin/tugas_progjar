import sys
import socket, json
import select
import os
from threading import Thread

server_address = ('127.0.0.1', 5000)
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
server_socket.bind(server_address)
server_socket.listen(5)

input_socket = [server_socket]

class ClientThread(Thread):
    def __init__(self, client_address, sock):
        Thread.__init__(self)
        self.client_address = client_address
        self.sock = sock

    def run(self):
        namafile = self.sock.recv(1024)
        namafile2 = namafile.strip('\n')
        print namafile2
        header = []
        size = os.path.getsize('dataset/'+namafile2)
        header.append(client_address)
        header.append(size)
        
        header2 = json.dumps(header)
        
        self.sock.send(header2)

        file = open('dataset/'+namafile2, 'rb')
        while True:
            data = file.read(1024)
            while (data):
                self.sock.send(data)
                # print 'Isi filenya => ', repr(data)
                # # print 'File berhasil dikirim'
                data = file.read(1024)
            if not data:
                file.close()
                self.sock.close()
                break

try:
    while True:
        read_ready, write_ready, exception = select.select(input_socket, [], []) #ini bikin error
        for sock in read_ready:
        	print 'menunggu client'
        	if sock == server_socket:
        		client_socket, client_address = server_socket.accept()
        		input_socket.append(client_socket)
        	else:
        
		        print client_socket.getpeername(), ' => sedang terhubung'
		        thread = ClientThread(client_address, client_socket)
		        thread.start()
		        input_socket.append(thread.sock)

except KeyboardInterrupt:
    server_socket.close()
    sys.exit(0)