import socket, json
import sys
import select
import math
server_address = ('127.0.0.1', 5000)
client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket.connect(server_address)

try:
	request = sys.stdin.readline()
	request2 = request.split(' ', 1)
	namaFile = request2[1]
	client_socket.send(namaFile)
	namaFile2 = namaFile.strip('\n')
	with open('downloads/'+namaFile2, 'wb') as file:
		print 'file terbuka'
		header = json.loads(client_socket.recv(1024))
		print 'ip add\t:',header[0][0]+'\nsize\t:',header[1]
		ukuran = math.ceil(header[1]/1024.0)
		i = 0
		while i < ukuran:
			data = client_socket.recv(1024) 
			# message = sys.stdin.readline()
			# client_socket.send(message)
			file.write(data)


			if not data:
				file.close()
				print 'file close()'
				break	
			i+=1		

except KeyboardInterrupt:
	client_socket.close()
	sys.exit(0)